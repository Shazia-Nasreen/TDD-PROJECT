package org.example.atm;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MockitoTest {

    @Test
    public void testGetBankName_ShouldReturnCorrectName() {
        // Mock the static method
        Bank mockBank = mock(Bank.class);
        when(mockBank.getBankName()).thenReturn("Mock Bank");

        assertEquals("Mock Bank", mockBank.getBankName());
    }
}
