package org.example.atm;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BankImplTest {

    private BankImpl bank;
    private BankAccount account;

    @BeforeEach
    void setUp() {
        // Create a new BankImpl instance and a sample BankAccount before each test
        bank = new BankImpl("Test Bank");
        account = new BankAccount(12345, "1234", 1000.0);
        bank.addAccount(account);  // Add the account to the bank
    }

    @Test
    void addAccount() {
        // Test if the account is added successfully
        BankAccount retrievedAccount = bank.getAccount(12345);
        assertNotNull(retrievedAccount);
        assertEquals(12345, retrievedAccount.getCardId());
    }

    @Test
    void verifyPin() {
        // Test PIN verification
        assertTrue(bank.verifyPin(12345, "1234"));  // Correct PIN
        assertFalse(bank.verifyPin(12345, "wrong"));  // Incorrect PIN
    }

    @Test
    void getBalance() {
        // Test balance retrieval
        assertEquals(1000.0, bank.getBalance(12345));
    }

    @Test
    void deposit() {
        // Test depositing money
        bank.deposit(12345, 500.0);
        assertEquals(1500.0, bank.getBalance(12345));  // Balance should be 1000 + 500 = 1500
    }

    @Test
    void withdraw() {
        // Test withdrawing money
        bank.withdraw(12345, 300.0);
        assertEquals(700.0, bank.getBalance(12345));  // Balance should be 1000 - 300 = 700
    }

    @Test
    void isCardLocked() {
        // Test if the card is locked
        assertFalse(bank.isCardLocked(12345));  // Card is not locked initially
    }

    @Test
    void getFailedAttempts() {
        // Test failed login attempts
        assertEquals(0, bank.getFailedAttempts(12345));  // No failed attempts yet
    }

    @Test
    void incrementFailedAttempts() {
        // Test incrementing failed attempts
        bank.incrementFailedAttempts(12345);
        assertEquals(1, bank.getFailedAttempts(12345));  // One failed attempt
    }

    @Test
    void lockCard() {
        // Test locking the card
        bank.lockCard(12345);
        assertTrue(bank.isCardLocked(12345));  // Card should be locked after calling lockCard
    }

    @Test
    void getBankName() {
        // Test getting the bank name
        assertEquals("Test Bank", bank.getBankName());
    }

    @Test
    void getAccount() {
        // Test getting the account by card ID
        BankAccount retrievedAccount = bank.getAccount(12345);
        assertNotNull(retrievedAccount);
        assertEquals(account, retrievedAccount);  // Should retrieve the exact account we added
    }
}
