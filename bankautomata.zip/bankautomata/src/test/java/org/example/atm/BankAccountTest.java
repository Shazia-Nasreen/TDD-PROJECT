package org.example.atm;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BankAccountTest {

    private BankAccount account;

    @BeforeEach
    void setUp() {
        // Initialize a BankAccount before each test
        account = new BankAccount(12345, "1234", 1000.0);
    }

    @Test
    void verifyPinTest() {
        // Test correct PIN
        assertTrue(account.verifyPin("1234"));

        // Test incorrect PIN
        assertFalse(account.verifyPin("wrongPin"));
    }

    @Test
    void depositTest() {
        // Initial balance
        assertEquals(1000.0, account.getBalance());

        // Deposit money
        account.deposit(500.0);
        assertEquals(1500.0, account.getBalance());
    }

    @Test
    void withdrawTest() {
        // Initial balance
        assertEquals(1000.0, account.getBalance());

        // Withdraw money
        account.withdraw(200.0);
        assertEquals(800.0, account.getBalance());

        // Try to withdraw more than available balance
        account.withdraw(1000.0);
        assertEquals(800.0, account.getBalance()); // Balance should not change
    }

    @Test
    void isLockedTest() {
        // Initially the account should not be locked
        assertFalse(account.isLocked());

        // Increment failed attempts 3 times
        account.incrementFailedAttempts();
        account.incrementFailedAttempts();
        account.incrementFailedAttempts();

        // Account should be locked after 3 failed attempts
        assertTrue(account.isLocked());
    }

    @Test
    void incrementFailedAttemptsTest() {
        // Check initial failed attempts count
        assertEquals(0, account.getFailedAttempts());

        // Increment failed attempts
        account.incrementFailedAttempts();
        assertEquals(1, account.getFailedAttempts());

        account.incrementFailedAttempts();
        assertEquals(2, account.getFailedAttempts());

        account.incrementFailedAttempts();
        assertEquals(3, account.getFailedAttempts()); // This should lock the account
    }

    @Test
    void lockTest() {
        // Initially the account should not be locked
        assertFalse(account.isLocked());

        // Lock the account
        account.lock();
        assertTrue(account.isLocked());
    }

    @Test
    void getBalanceTest() {
        assertEquals(1000.0, account.getBalance());
    }

    @Test
    void getCardIdTest() {
        assertEquals(12345, account.getCardId());
    }
}
