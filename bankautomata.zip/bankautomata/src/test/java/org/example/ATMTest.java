package org.example.atm;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Scanner;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class ATMTest {

    private Bank mockBank;
    private ATM atm;
    private BankAccount mockAccount;

    @BeforeEach
    void setUp() {
        mockBank = mock(Bank.class);  // Create mock Bank
        atm = new ATM(mockBank);      // Create ATM with the mocked bank
        mockAccount = new BankAccount(1234, "5678", 1000.0);  // Create a sample account
    }

    @Test
    void testInsertCard_ValidCard() {
        when(mockBank.getAccount(1234)).thenReturn(mockAccount);

        atm.insertCard(1234);

        verify(mockBank).getAccount(1234);
        assertNotNull(atm.getCurrentAccount());  // Account should be set in ATM
    }

    @Test
    void testInsertCard_InvalidCard() {
        when(mockBank.getAccount(9999)).thenReturn(null);

        atm.insertCard(9999);

        verify(mockBank).getAccount(9999);
        assertNull(atm.getCurrentAccount());  // No account should be set
    }

    @Test
    void testEnterPin_CorrectPin() {
        when(mockBank.getAccount(1234)).thenReturn(mockAccount);
        when(mockBank.verifyPin(1234, "5678")).thenReturn(true);

        atm.insertCard(1234);  // Ensure the card is inserted
        boolean result = atm.enterPinInput(new Scanner("5678"));

        assertTrue(result);
        verify(mockBank).verifyPin(1234, "5678");
    }

    @Test
    void testEnterPin_IncorrectPin() {
        when(mockBank.getAccount(1234)).thenReturn(mockAccount);
        when(mockBank.verifyPin(1234, "0000")).thenReturn(false); // Mock incorrect PIN
        when(mockBank.getFailedAttempts(1234)).thenReturn(1);

        atm.insertCard(1234);  // Ensure the card is inserted
        boolean result = atm.enterPinInput(new Scanner("0000"));  // Incorrect PIN

        assertFalse(result);
        verify(mockBank).incrementFailedAttempts(1234);  // Verify increment on incorrect PIN
    }

    @Test
    void testCheckBalance() {
        when(mockBank.getAccount(1234)).thenReturn(mockAccount);
        when(mockBank.verifyPin(1234, "5678")).thenReturn(true);
        when(mockBank.getBalance(1234)).thenReturn(1000.0);

        atm.insertCard(1234);
        atm.enterPinInput(new Scanner("5678"));

        double balance = atm.checkBalance();
        assertEquals(1000.0, balance);
        verify(mockBank).getBalance(1234);
    }

    @Test
    void testDepositMoney() {
        when(mockBank.getAccount(1234)).thenReturn(mockAccount);
        when(mockBank.verifyPin(1234, "5678")).thenReturn(true);

        atm.insertCard(1234);
        atm.enterPinInput(new Scanner("5678"));

        atm.depositMoney(500.0);
        verify(mockBank).deposit(1234, 500.0);
    }

    @Test
    void testWithdrawMoney_ValidAmount() {
        when(mockBank.getAccount(1234)).thenReturn(mockAccount);
        when(mockBank.verifyPin(1234, "5678")).thenReturn(true);
        when(mockBank.getBalance(1234)).thenReturn(1000.0);

        atm.insertCard(1234);
        atm.enterPinInput(new Scanner("5678"));

        boolean result = atm.withdrawMoney(200.0);
        assertTrue(result);  // Withdrawal should succeed
        verify(mockBank).withdraw(1234, 200.0);
    }

    @Test
    void testWithdrawMoney_InsufficientFunds() {
        when(mockBank.getAccount(1234)).thenReturn(mockAccount);
        when(mockBank.verifyPin(1234, "5678")).thenReturn(true);
        when(mockBank.getBalance(1234)).thenReturn(100.0);  // Insufficient balance

        atm.insertCard(1234);
        atm.enterPinInput(new Scanner("5678"));

        boolean result = atm.withdrawMoney(200.0);
        assertFalse(result);  // Withdrawal should fail
        verify(mockBank, never()).withdraw(1234, 200.0);  // Should not call withdraw
    }
}
