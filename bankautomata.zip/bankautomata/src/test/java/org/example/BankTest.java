package org.example.atm;

import static org.mockito.Mockito.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BankTest {

    private BankImpl bank;
    private BankAccount account;

    @BeforeEach
    public void setUp() {
        bank = new BankImpl();
        account = new BankAccount(1234, "5678", 1000.0);
        bank.addAccount(account);
    }

    @Test
    public void testVerifyPin_ShouldReturnTrue_WhenPinIsCorrect() {
        boolean result = bank.verifyPin(1234, "5678");
        assertTrue(result);
    }

    @Test
    public void testVerifyPin_ShouldReturnFalse_WhenPinIsIncorrect() {
        boolean result = bank.verifyPin(1234, "wrong");
        assertFalse(result);
    }

    @Test
    public void testBalance_ShouldReturnCorrectBalance() {
        double balance = bank.getBalance(1234);
        assertEquals(1000.0, balance);
    }
}
