package org.example.atm;
public interface Bank {
    void addAccount(BankAccount account);
    boolean verifyPin(int cardId, String pin);
    double getBalance(int cardId);
    void deposit(int cardId, double amount);
    void withdraw(int cardId, double amount); // Ensure this method is here
    boolean isCardLocked(int cardId);
    int getFailedAttempts(int cardId);
    void incrementFailedAttempts(int cardId);
    void lockCard(int cardId);
    String getBankName();
    BankAccount getAccount(int cardId);
}
