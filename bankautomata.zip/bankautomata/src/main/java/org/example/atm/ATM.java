package org.example.atm;

import java.util.Scanner;

public class ATM {
    private Bank bank;
    private BankAccount currentAccount;

    public ATM(Bank bank) {
        this.bank = bank;
    }

    public void insertCard(int cardId) {
        currentAccount = bank.getAccount(cardId);
    }

    public BankAccount getCurrentAccount() {
        return currentAccount;
    }

    public boolean enterPinInput(Scanner scanner) {
        if (currentAccount == null) {
            return false;
        }
        String pin = scanner.nextLine();
        boolean isPinCorrect = bank.verifyPin(currentAccount.getCardId(), pin);
        if (!isPinCorrect) {
            bank.incrementFailedAttempts(currentAccount.getCardId());
        }
        return isPinCorrect;
    }

    public double checkBalance() {
        if (currentAccount != null) {
            return bank.getBalance(currentAccount.getCardId());
        }
        return 0.0;
    }

    public void depositMoney(double amount) {
        if (currentAccount != null) {
            bank.deposit(currentAccount.getCardId(), amount);
        }
    }

    public boolean withdrawMoney(double amount) {
        if (currentAccount != null && bank.getBalance(currentAccount.getCardId()) >= amount) {
            bank.withdraw(currentAccount.getCardId(), amount);
            return true;
        }
        return false;
    }
}
