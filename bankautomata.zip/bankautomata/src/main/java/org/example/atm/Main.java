package org.example.atm;

import java.util.Scanner;

public class Main {

    private static double balance = 1000.0; // Initial balance

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Display welcome message
        System.out.println("Välkommen till Bankomaten");

        // ATM interaction loop
        while (true) {
            System.out.println("Välj ett alternativ:");
            System.out.println("1. Kontrollera saldo");
            System.out.println("2. Sätt in pengar");
            System.out.println("3. Ta ut pengar");
            System.out.println("4. Avsluta");

            // Read user choice
            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1: // Check balance
                    System.out.println("Ditt saldo är: " + balance);
                    break;
                case 2: // Deposit money
                    System.out.println("Ange belopp att sätta in:");
                    double depositAmount = Double.parseDouble(scanner.nextLine());
                    balance += depositAmount;
                    System.out.println("Ditt saldo är: " + balance);
                    break;
                case 3: // Withdraw money
                    System.out.println("Ange belopp att ta ut:");
                    double withdrawalAmount = Double.parseDouble(scanner.nextLine());
                    if (balance >= withdrawalAmount) {
                        balance -= withdrawalAmount;
                        System.out.println("Ditt saldo är: " + balance);
                    } else {
                        System.out.println("Otillräckligt saldo.");
                    }
                    break;
                case 4: // End session
                    System.out.println("Avslutar programmet.");
                    return;
                default:
                    System.out.println("Ogiltigt alternativ, försök igen.");
            }
        }
    }
}
