package org.example.atm;

import java.util.HashMap;
import java.util.Map;

public class BankImpl implements Bank {
    private String bankName;
    private Map<Integer, BankAccount> accounts;

    // Default constructor with default bank name
    public BankImpl() {
        this.bankName = "Unnamed Bank";  // Default name if none is provided
        this.accounts = new HashMap<>();
    }

    // Constructor allowing for a custom bank name
    public BankImpl(String bankName) {
        this.bankName = bankName;
        this.accounts = new HashMap<>();
    }

    @Override
    public void addAccount(BankAccount account) {
        accounts.put(account.getCardId(), account);
    }

    @Override
    public boolean verifyPin(int cardId, String pin) {
        BankAccount account = accounts.get(cardId);
        return account != null && account.verifyPin(pin);
    }

    @Override
    public double getBalance(int cardId) {
        BankAccount account = accounts.get(cardId);
        return account != null ? account.getBalance() : 0.0;
    }

    @Override
    public void deposit(int cardId, double amount) {
        BankAccount account = accounts.get(cardId);
        if (account != null) {
            account.deposit(amount);
        }
    }

    @Override
    public void withdraw(int cardId, double amount) {
        BankAccount account = accounts.get(cardId);
        if (account != null) {
            account.withdraw(amount);
        }
    }

    @Override
    public boolean isCardLocked(int cardId) {
        BankAccount account = accounts.get(cardId);
        return account != null && account.isLocked();
    }

    @Override
    public int getFailedAttempts(int cardId) {
        BankAccount account = accounts.get(cardId);
        return account != null ? account.getFailedAttempts() : 0;
    }

    @Override
    public void incrementFailedAttempts(int cardId) {
        BankAccount account = accounts.get(cardId);
        if (account != null) {
            account.incrementFailedAttempts();
        }
    }

    @Override
    public void lockCard(int cardId) {
        BankAccount account = accounts.get(cardId);
        if (account != null) {
            account.lock();
        }
    }

    @Override
    public String getBankName() {
        return bankName;
    }

    @Override
    public BankAccount getAccount(int cardId) {
        return accounts.get(cardId);
    }
}
