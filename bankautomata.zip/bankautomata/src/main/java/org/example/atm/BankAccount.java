package org.example.atm;

public class BankAccount {
    private int cardId;
    private String pin;
    private double balance;
    private boolean locked;
    private int failedAttempts;

    // Constructor
    public BankAccount(int cardId, String pin, double initialBalance) {
        this.cardId = cardId;
        this.pin = pin;
        this.balance = initialBalance;
        this.locked = false;
        this.failedAttempts = 0;
    }

    public int getCardId() {
        return cardId;
    }

    public boolean verifyPin(String pin) {
        // Method implementation
        return pin.equals(this.pin);  // Example of returning a boolean
    }


    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        if (!locked && balance >= amount) {
            balance -= amount;
        }
    }

    public boolean isLocked() {
        return locked;
    }

    public int getFailedAttempts() {
        return failedAttempts;
    }

    public void incrementFailedAttempts() {
        failedAttempts++;
        if (failedAttempts >= 3) {
            lock(); // Lock the account if failed attempts exceed 3
        }
    }

    public void lock() {
        locked = true; // Lock the account
    }
}

